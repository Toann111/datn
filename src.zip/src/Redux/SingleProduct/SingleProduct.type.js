export const GET_SINGLE_PRODUCT_LOADING = "singleProduct/loading";
export const GET_SINGLE_PRODUCT_SUCCESS = "singleProduct/success";
export const GET_SINGLE_PRODUCT_ERROR = "singleProduct/error";
